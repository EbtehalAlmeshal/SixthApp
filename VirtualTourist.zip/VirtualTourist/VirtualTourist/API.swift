//
//  API.swift
//  VirtualTourist
//
//  Created by Ebtehal 🕸 on 26/03/1440 AH.
//  Copyright © 1440 Ebtehal 🕸. All rights reserved.
//

import Foundation
import MapKit
import CoreData

//Key:96b8ef3274352001014e213722216009
//Secret:0b3321d7fac5c58d



struct API {
    
    struct Flickr {
        
        static func getPhotos(with coordinate: CLLocationCoordinate2D, pageNumber: Int, completion: @escaping ([URL]?, Error?, String?) -> ()) {
            let methodParameters = [
                Constants.FlickrParameterKeys.Method: Constants.FlickrParameterValues.SearchMethod,
                Constants.FlickrParameterKeys.APIKey: Constants.FlickrParameterValues.APIKey,
                Constants.FlickrParameterKeys.BoundingBox: bboxString(for: coordinate),
                Constants.FlickrParameterKeys.SafeSearch: Constants.FlickrParameterValues.UseSafeSearch,
                Constants.FlickrParameterKeys.Extras: Constants.FlickrParameterValues.MediumURL,
                Constants.FlickrParameterKeys.Format: Constants.FlickrParameterValues.ResponseFormat,
                Constants.FlickrParameterKeys.NoJSONCallback: Constants.FlickrParameterValues.DisableJSONCallback,
                Constants.FlickrParameterKeys.Page: pageNumber,
                Constants.FlickrParameterKeys.PerPage: 15,
                ] as [String:Any]
            
            let request = URLRequest(url: getURL(from: methodParameters))
            
            let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
                
                guard (error == nil) else {
                    completion(nil, error, nil)
                    return
                }
                
                guard let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode >= 200 && statusCode <= 299 else {
                    completion(nil, nil, "Your request returned a status code other than 2xx!")
                    return
                }
                
                guard let data = data else {
                    completion(nil, nil, "No data was returned by the request!")
                    return
                }
                
                guard let parsedResult = try? JSONSerialization.jsonObject(with: data, options: .allowFragments) as! [String:Any] else {
                    completion(nil, nil, "Could not parse the data as JSON: '\(data)'")
                    return
                }
                
                guard let stat = parsedResult[Constants.FlickrResponseKeys.Status] as? String, stat == Constants.FlickrResponseValues.OKStatus else {
                    completion(nil, nil, "Flickr API returned an error. See error code and message in \(parsedResult)")
                    return
                }
                
                guard let photosDictionary = parsedResult[Constants.FlickrResponseKeys.Photos] as? [String:Any] else {
                    completion(nil, nil, "Cannot find key '\(Constants.FlickrResponseKeys.Photos)' in \(parsedResult)")
                    return
                }
                
                guard let photosArray = photosDictionary[Constants.FlickrResponseKeys.Photo] as? [[String:Any]] else {
                    completion(nil, nil, "Cannot find key '\(Constants.FlickrResponseKeys.Photo)' in \(photosDictionary)")
                    return
                }
                
                let photosURLs = photosArray.compactMap { photoDictionary -> URL? in
                    guard let url = photoDictionary[Constants.FlickrResponseKeys.MediumURL] as? String else { return nil}
                    return URL(string: url)
                }
                
                completion(photosURLs, nil, nil)
            }
            
            task.resume()
        }
        static func getImageForPhoto(url: String, handler: @escaping (Data) -> Void) {
            
            let url = URL(string: url)
            let session = URLSession.shared
            let photoTask = session.dataTask(with: url!, completionHandler: { data,reponse,error in
                
                if error == nil {
                    let imageData = data
                    DispatchQueue.main.async {
                        handler(imageData!)
                    }
                    
                } else {
                    print("Error getting image data")
                }
                
            })
            
            photoTask.resume()
        }
        static func bboxString(for coordinate: CLLocationCoordinate2D) -> String {
            let latitude = coordinate.latitude
            let longitude = coordinate.longitude
            
            let minimumLon = max(longitude - Constants.Flickr.SearchBBoxHalfWidth, Constants.Flickr.SearchLonRange.0)
            let minimumLat = max(latitude - Constants.Flickr.SearchBBoxHalfHeight, Constants.Flickr.SearchLatRange.0)
            let maximumLon = min(longitude + Constants.Flickr.SearchBBoxHalfWidth, Constants.Flickr.SearchLonRange.1)
            let maximumLat = min(latitude + Constants.Flickr.SearchBBoxHalfHeight, Constants.Flickr.SearchLatRange.1)
            
            return "\(minimumLon),\(minimumLat),\(maximumLon),\(maximumLat)"
        }
        
        static func getURL(from parameters: [String:Any]) -> URL {
            
            var components = URLComponents()
            components.scheme = Constants.Flickr.APIScheme
            components.host = Constants.Flickr.APIHost
            components.path = Constants.Flickr.APIPath
            components.queryItems = [URLQueryItem]()
            
            for (key, value) in parameters {
                let queryItem = URLQueryItem(name: key, value: "\(value)")
                components.queryItems!.append(queryItem)
            }
            
            return components.url!
        }
    }
    
}

struct Constants {
    
    struct Flickr {
        static let APIScheme = "https"
        static let APIHost = "api.flickr.com"
        static let APIPath = "/services/rest"
        
        static let SearchBBoxHalfWidth = 1.0
        static let SearchBBoxHalfHeight = 1.0
        static let SearchLatRange = (-90.0, 90.0)
        static let SearchLonRange = (-180.0, 180.0)
    }
    
    struct FlickrParameterKeys {
        static let Method = "method"
        static let APIKey = "api_key"
        static let Extras = "extras"
        static let Format = "format"
        static let NoJSONCallback = "nojsoncallback"
        static let SafeSearch = "safe_search"
        static let Text = "text"
        static let BoundingBox = "bbox"
        static let Page = "page"
        static let PerPage = "per_page"
    }
    
    struct FlickrParameterValues {
        static let SearchMethod = "flickr.photos.search"
        static let APIKey = "96b8ef3274352001014e213722216009"
        static let ResponseFormat = "json"
        static let DisableJSONCallback = "1" /* 1 means "yes" */
        static let GalleryPhotosMethod = "flickr.galleries.getPhotos"
        static let MediumURL = "url_m"
        static let UseSafeSearch = "1"
    }
    
    struct FlickrResponseKeys {
        static let Status = "stat"
        static let Photos = "photos"
        static let Photo = "photo"
        static let MediumURL = "url_m"
        static let Pages = "pages"
        static let Total = "total"
    }
    
    struct FlickrResponseValues {
        static let OKStatus = "ok"
    }
    
}





