//
//  TravelLocationsMap.swift
//  VirtualTourist
//
//  Created by Ebtehal 🕸 on 26/03/1440 AH.
//  Copyright © 1440 Ebtehal 🕸. All rights reserved.
//

import Foundation
import UIKit
import MapKit
import CoreData

class TravelLocationsMap : UIViewController {
    
    var fetchedResultsController: NSFetchedResultsController<Pin>!
    var dataController: DataController {
        return DataController.sharedInstance
    }
    
    @IBOutlet weak var mapView: MKMapView!
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setupFetchedResultsController()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        fetchedResultsController = nil
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let longPressRecogniser = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress(_:)))
        mapView.addGestureRecognizer(longPressRecogniser)
    }
    
    func setupFetchedResultsController() {
        let fetchRequest: NSFetchRequest<Pin> = Pin.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "creationDate", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: nil)
        fetchedResultsController.delegate = self as NSFetchedResultsControllerDelegate
        do {
            try fetchedResultsController.performFetch()
            updateMapView()
        } catch {
            fatalError("The fetch could not be performd: \(error.localizedDescription)")
        }
    }
    
    @objc func handleLongPress(_ gestureRecognizer: UIGestureRecognizer) {
        if gestureRecognizer.state != .began { return }
        let touchPoint = gestureRecognizer.location(in: mapView)
        
        let pin = Pin(context: dataController.viewContext)
        pin.coordinate = mapView.convert(touchPoint, toCoordinateFrom: mapView)
        try? dataController.viewContext.save()
    }
    
    func updateMapView() {
        guard let pins = fetchedResultsController.fetchedObjects else { return }
        print("Number of pins: \(pins.count)")
        for pin in pins {
            if mapView.annotations.contains(where: { pin.compare(to: $0.coordinate) }) { continue }
            let annotation = MKPointAnnotation()
            annotation.coordinate = pin.coordinate
            mapView.addAnnotation(annotation)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ToPhotoAlbum" {
            let PhotoAlbum = segue.destination as! PhotoAlbum
            PhotoAlbum.pin = fetchedResultsController.fetchedObjects?.filter { pin in pin.compare(to: mapView.selectedAnnotations.first!.coordinate) }.first!
        }
    }
    
}


extension TravelLocationsMap: MKMapViewDelegate {
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        DispatchQueue.main.async {
            self.performSegue(withIdentifier: "ToPhotoAlbum", sender: self)
        }
    }
}


extension TravelLocationsMap: NSFetchedResultsControllerDelegate {
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        updateMapView()
    }
    
    
    
    
    
    
    
    
    
    
}
