//
//  PhotoCell.swift
//  VirtualTourist
//
//  Created by Ebtehal 🕸 on 26/03/1440 AH.
//  Copyright © 1440 Ebtehal 🕸. All rights reserved.
//

import UIKit

class PhotoCell: UICollectionViewCell {
    
    
     @IBOutlet weak var imageView: CustomImageView!
    var imageUrl: URL? = nil

}
protocol CustomImageViewDelegate {
    func imageDidDownload()
}

let imagesCache = NSCache<NSString, AnyObject>()

class CustomImageView: UIImageView {
    
    var photo: Photo! {
        willSet {
            if let image = newValue.getImage() {
                hideActivityIndicatorView()
                self.image = image
            } else {
                if let url = newValue.imageUrl {
                    if photo == nil || photo.imageUrl == nil {
                        loadImageUsingCache(with: url)
                    }
                }
            }
        }
    }
    
    var imageURL: URL!
    
    lazy var activityIndicatorView: UIActivityIndicatorView = {
        let activityIndicatorView = UIActivityIndicatorView(style: .whiteLarge)
        activityIndicatorView.center(to: self)
        activityIndicatorView.color = .black
        activityIndicatorView.hidesWhenStopped = true
        return activityIndicatorView
    }()
    
    func showActivityIndicatorView() {
        DispatchQueue.main.async {
            self.activityIndicatorView.startAnimating()
        }
    }
    
    func hideActivityIndicatorView() {
        DispatchQueue.main.async {
            self.activityIndicatorView.stopAnimating()
        }
    }
    
    func loadImageUsingCache(with url: URL) {
        print("here we go!")
        imageURL = url
        image = nil
        showActivityIndicatorView()
        if let cachedImage = imagesCache.object(forKey: url.absoluteString as NSString) as? UIImage {
            image = cachedImage
            hideActivityIndicatorView()
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let error = error {
                print(error.localizedDescription)
                return
            }
            guard let DownloadedImage = UIImage(data: data!) else { return }
            DispatchQueue.main.async {
                if self.imageURL == url {
                    self.image = DownloadedImage
                    self.photo.set(image: DownloadedImage)
                    try? self.photo.managedObjectContext?.save()
                    self.hideActivityIndicatorView()
                }
                imagesCache.setObject(DownloadedImage, forKey:  url.absoluteString as NSString)
            }
            
        }
        task.resume()
    }
}
