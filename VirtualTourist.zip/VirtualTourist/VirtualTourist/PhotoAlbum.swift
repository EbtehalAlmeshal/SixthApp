//
//  PhotoAlbum.swift
//  VirtualTourist
//
//  Created by Ebtehal 🕸 on 26/03/1440 AH.
//  Copyright © 1440 Ebtehal 🕸. All rights reserved.
//

import Foundation
import UIKit
import MapKit
import CoreData

class PhotoAlbum : UIViewController {
    
    let photoCellId = "cell"
    var pin: Pin!
    var pageNumber = 1
    var fetchedResultsController: NSFetchedResultsController<Photo>!
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var buttonBar: UIBarButtonItem!
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var activityIndicatorView: UIActivityIndicatorView!
    @IBOutlet weak var layout: UICollectionViewFlowLayout!
  
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setupFetchedResultsController()
        collectionView.reloadData()
        
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        fetchedResultsController = nil
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let collectionLayout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
            let length = (view.bounds.width - 20) / 3
            collectionLayout.itemSize = CGSize(width: length, height: length)
            collectionLayout.minimumLineSpacing = 15
        }
    }

    
    func setupFetchedResultsController() {
        let fetchRequest: NSFetchRequest<Photo> = Photo.fetchRequest()
        let predicate = NSPredicate(format: "pin == %@", pin)
        fetchRequest.predicate = predicate
        let sortDescriptor = NSSortDescriptor(key: "creationDate", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: DataController.sharedInstance.viewContext, sectionNameKeyPath: nil, cacheName: nil)
        fetchedResultsController.delegate = self
        do {
            try fetchedResultsController.performFetch()
            if (fetchedResultsController.fetchedObjects?.count ?? 0) == 0 {
                buttonTapped(self)
            } else {
                updateUI(processing: false)
            }
        } catch {
            fatalError("The fetch could not be performd: \(error.localizedDescription)")
        }
    }
    
    @IBAction func buttonTapped(_ sender: Any) {
        updateUI(processing: true)
        
        if (fetchedResultsController.fetchedObjects?.count ?? 0) != 0 {
            for photo in fetchedResultsController.fetchedObjects! {
                DataController.sharedInstance.viewContext.delete(photo)
            }
            try? DataController.sharedInstance.viewContext.save()
        }
        API.Flickr.getPhotos(with: pin.coordinate, pageNumber: pageNumber) { (urls, error, errorMessage) in
            guard (error == nil) else {
                self.alert(title: "Error", message: "\(error!.localizedDescription)")
                return
            }
            
            guard (errorMessage == nil) else {
                self.alert(title: "Error", message: "\(errorMessage!)")
                return
            }
            
            for url in urls! {
            let photo = Photo(context: DataController.sharedInstance.viewContext)
               photo.imageUrl = url
               photo.pin = self.pin
            }
            try? DataController.sharedInstance.viewContext.save()
            
            DispatchQueue.main.async {
                self.updateUI(processing: false)
                self.messageLabel.isHidden = ((urls?.count ?? 0) != 0)
            }
        }
        pageNumber += 1
    }
    
    func updateUI(processing: Bool) {
        collectionView.isUserInteractionEnabled = !processing
        if processing {
            buttonBar.title = ""
            activityIndicatorView.startAnimating()
            
        } else {
            activityIndicatorView.stopAnimating()
            buttonBar.title = "New Collection"
        }
    }

}
extension PhotoAlbum: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return fetchedResultsController.fetchedObjects?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! PhotoCell
         cell.imageView.image = nil
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        let photo  = fetchedResultsController.object(at: indexPath)
        let photoViewCell = cell as! PhotoCell
        photoViewCell.imageUrl = photo.imageUrl!
        configImage(using: photoViewCell , photo: photo, index: indexPath)
    }
    private func configImage (using cell : PhotoCell , photo : Photo , index : IndexPath ){
        if let imageData = photo.image{
            cell.imageView.image = UIImage(named: "placeholders")
            cell.imageView.image = UIImage(data: imageData)
            
        } else {
            if let imageUrl = photo.imageUrl {
                cell.imageView.image = UIImage(named: "placeholders")
                API.Flickr.getImageForPhoto(url: imageUrl.absoluteString, handler: { data in
                    if cell.imageUrl == imageUrl {
                    cell.imageView.image = UIImage(data: data)
                    }
                    photo.image = Data(data)
                    DispatchQueue.global(qos: .background).async {
                       self.save()
                    }
                    
                    })
            }
        }
      
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let photo = fetchedResultsController.object(at: indexPath)
        DataController.sharedInstance.viewContext.delete(photo)
        try? DataController.sharedInstance.viewContext.save()
    }
}

extension PhotoAlbum: NSFetchedResultsControllerDelegate {
    func save() {
        do {
            try DataController.sharedInstance.saveContext()
        } catch {
            alert(title: "Error", message: "Error while saving Pin location: \(error)")
        }
    }
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch type {
        case .insert, .delete:
            DispatchQueue.main.async {
                self.collectionView.reloadData()
                print(self.collectionView.numberOfItems(inSection: 0))
            }
        default:
            return
        }
    }
    
    
    
    
}
