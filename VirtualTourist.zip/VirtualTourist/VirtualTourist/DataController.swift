//
//  DataController.swift
//  VirtualTourist
//
//  Created by Ebtehal 🕸 on 26/03/1440 AH.
//  Copyright © 1440 Ebtehal 🕸. All rights reserved.
//

import Foundation
import CoreData
class DataController {

    static let sharedInstance = DataController()
    
    let persistentContainer = NSPersistentContainer(name: "VirtualTourist")
    
    var viewContext: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    func load(completion: (() -> ())? = nil) {
        persistentContainer.loadPersistentStores { (storeDescription, error) in
            guard error == nil else {
                fatalError(error!.localizedDescription)
            }
            completion?()
        }
    }
    
    func saveContext() throws {
        viewContext.performAndWait() {
            
            if self.viewContext.hasChanges {
                do {
                    try self.viewContext.save()
                } catch {
                    print("Error while saving main context: \(error)")
                }
                
                self.viewContext.perform() {
                    do {
                        try self.viewContext.save()
                    } catch {
                        print("Error while saving persisting context: \(error)")
                    }
                }
            }
        }
    }
    
    
    
    
    
}
